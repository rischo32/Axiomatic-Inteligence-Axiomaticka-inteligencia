# Contributor License Agreement (CLA) — AEPL-1.0

Týmto:
- potvrdzujem, že som autor príspevku alebo mám právo ho poskytnúť,
- udeľujem nevýhradnú licenciu môjho príspevku pod AEPL-1.0,
- potvrdzujem, že môj príspevok nespôsobí porušenie etických zásad AEPL-1.0 (HEXA7),
- súhlasím so zverejnením mena v CONTRIBUTORS.md po akceptovaní príspevku.

Dátum: __________
Meno: __________
GitHub profil: https://github.com/__________
Elektronický podpis / PR merge: __________
