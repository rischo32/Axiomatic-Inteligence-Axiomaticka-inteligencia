NOTICE — Axiom Engine / Axiomatická Inteligencia (AEPL-1.0)

Pôvodné dielo: Axiomatická Inteligencia — Richard Fonfára (2025)
Repozitár: https://github.com/Rischo32

Licencia: AEPL-1.0
Dátová licencia (akákoľvek): CC BY-SA 4.0 (ak nie je uvedené inak)
