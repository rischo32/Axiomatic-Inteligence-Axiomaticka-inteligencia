CONTRIBUTORS — Axiomatická Inteligencia (registro spolutvorcov)

Formát záznamu:
- Meno / GitHub: [meno] — https://github.com/username
- Dátum zápisu: YYYY-MM-DD
- Typ príspevku: {kód | dokumentácia | preklad | školenie | implementácia | iné}
- Krátky popis príspevku
- Odkaz na PR/artefakt

Postup zápisu:
1) PR alebo verejný záznam,
2) podpísať CLA,
3) schválenie udržiavateľom alebo CCC.
