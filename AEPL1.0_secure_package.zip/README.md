# Axiomatická Inteligencia — AEPL-1.0 Secure Package

Tento balík obsahuje AEPL-1.0 (Axiom Engine Public License v1.0) a súvisiace metadáta pripravené pre registráciu (DOI) a vloženie do repozitára.

Autor: Richard Fonfára (Rischo32)
Dátum generovania: 2025-10-29

Obsah balíka:
- AEPL-1.0.txt        (plné znenie licencie)
- LICENSE.json        (strojovo čitateľné meta informácie + SHA256)
- meta.yaml           (metadata pre Zenodo/Datacite submission)
- README.md           (tento súbor)
- CLA.md              (Contributor License Agreement template)
- NOTICE.md           (krátke zhrnutie atribúcie)
- CONTRIBUTORS.md     (šablóna)
- submission_form.md  (návod krok-po-kroku pre registráciu DOI / AEPL-1.0.sk)

Použitie:
1) Skontroluj AEPL-1.0.txt a uprav podľa posledných požiadaviek.
2) Nahraj súbory na Zenodo alebo Datacite, získaj DOI a aktualizuj pole 'doi' v meta.yaml a LICENSE.json.
3) Nahraj tento balík do repozitára https://github.com/Rischo32 a vytvor release s DOI v popise.
