Submission / Registration instructions — AEPL-1.0 DOI (suggested)

1) Create an account on Zenodo (https://zenodo.org) or Figshare (https://figshare.com).
2) Prepare the package: AEPL-1.0.txt, meta.yaml, LICENSE.json, README.md, NOTICE.md, CLA.md, CONTRIBUTORS.md.
3) Upload files and fill metadata:
   - Title: AEPL-1.0 — Axiom Engine Public License (Axiomatic Ethical Permission License v1.0)
   - Authors: Richard Fonfára (Rischo32)
   - Description: Custom ethical license for Axiomatic Intelligence framework. Includes machine-readable license.json and metadata for DOI registration.
   - Keywords: AEPL, Axiom Engine, ethical license, AI ethics, HEXA7
4) Submit and obtain DOI. Update 'doi' field in meta.yaml and LICENSE.json with the assigned DOI and SHA256 of AEPL-1.0.txt.
5) Create a GitHub release on https://github.com/Rischo32 including the DOI and ZIP package.

Optional: Register AEPL-1.0.sk by creating a simple static page hosting AEPL-1.0.txt, meta.yaml and DOI link. Consider adding PGP signature and blockchain anchoring for long-term immutability.
